temp_list = [
  {
    product_name: "The Ordinary Face Serum",
    ingredients:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    color_matched: true,
    score: 0.85,
    category: "Concealer",
  },
  {
    product_name: "Luminous Silk Foundation",
    ingredients:
      "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    color_matched: true,
    image_link:
      "https://www.sephora.com/productimages/sku/s1359694-main-zoom.jpg?imwidth=465",
    score: 0.84,
  },
  {
    product_name: "Estee Lauder Foundation",
    ingredients:
      "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    color_matched: false,
    image_link:
      "https://www.sephora.com/productimages/sku/s2602043-main-zoom.jpg?imwidth=465",
    score: 0.73,
  },
  {
    product_name: "NARS Foundation",
    ingredients:
      "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
    color_matched: true,
    image_link:
      "https://www.sephora.com/productimages/sku/s2842276-main-zoom.jpg?imwidth=465",
    score: 0.82,
  },
];

const scrollContainer = document.getElementById("photos-section-id");

// Function to handle automatic scrolling based on mouse position
function handleMouseMove(event) {
  const containerWidth = scrollContainer.offsetWidth;
  const mouseX = event.clientX - scrollContainer.getBoundingClientRect().left;
  const scrollSpeed = 2; // Adjust the scroll speed if needed

  // Calculate how far the mouse is from the left or right edge
  const scrollPosition = mouseX / containerWidth;

  // Scroll the container based on mouse position (0 = left, 1 = right)
  scrollContainer.scrollLeft = scrollPosition * (scrollContainer.scrollWidth - containerWidth);
}

// Add event listener for mouse move inside the container
scrollContainer.addEventListener('mousemove', handleMouseMove);

/*document.addEventListener("click", function (event) {
  const popup = document.querySelector(".popup-content"); // Get the popup content element

  // If the clicked area is outside the popup content, close the popup
  if (!popup.contains(event.target)) {
    window.close(); // This closes the popup
  }
}); */

function load_images(object_list) {
  const img_section = document.getElementById("photos-section-id");
  img_section.innerHTML = "";
  object_list.forEach((single, index) => {
    const temp_wrapper = document.createElement("a");
    const temp_img = document.createElement("img");

    if (typeof single.image_link == "string") {
      temp_img.src = single.image_link;
    } else {
      rand_img_number = Math.floor(Math.random() * (5 - 1 + 1) + 1);
      temp_img.src = "./images/Blank Picture " + rand_img_number + ".png";
    }
    temp_img.classList.add("item-img");
    temp_img.setAttribute("data-product-id", index);
    if (index === 0) {
      temp_img.classList.add("active");
    }
    temp_wrapper.append(temp_img);
    img_section.append(temp_wrapper);
  });
}

function load_info(prod_index) {
  const selected_product = temp_list[prod_index];
  document.getElementById("productTitle").textContent =
    selected_product.product_name;
  temp_similar = Math.round(parseFloat(selected_product.score) * 100);
  document.getElementById("sim-score").textContent =
    "Similarity Score: " + temp_similar.toString() + "%";
  //document.getElementById("prod-ingredients").textContent =
  selected_product.ingredients;
}

document.addEventListener("DOMContentLoaded", function () {
  //let currentURL = '';
  //chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  //currentURL = tabs[0].url;

  //}).then(
  //console.log("CURRENT URL", currentURL);
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    page_url = tabs[0].url;

    if (page_url.includes("sephora.com") & page_url.includes("skuId")) {
      let final_api_url =
        "https://x9srsa41k6.execute-api.us-east-1.amazonaws.com/dev/api/predict-dupes";

      let test_api_input = {
        ingredients:
          "Aqua/Water/Eau, Glycerin, Butylene Glycol, Glycereth-26, 1,2-Hexanediol, Niacinamide, Camellia Sinensis Seed Oil, Methylpropanediol, Panthenol, Chlorella Vulgaris Extract, Glucose, Acrylates/C10-30 Alkyl Acrylate Crosspolymer, Fructooligosaccharides, Fructose, Hydrogenated Lecithin, Sodium Polyacryloyldimethyl Taurate, Yeast Ferment Extract, Tromethamine, Dipotassium Glycyrrhizate, Ethylhexylglycerin, Sodium Phytate, Candida Bombicola/Glucose/Methyl Rapeseedate Ferment, Tocopherol.",
        top_n: 5,
      };

      function assign_ingredients(response) {
        return response.ingredients;
      }
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: "getProductIngredients" },
          (response) => {
            console.log(response);
            const productIngredients = response.ingredients;
            console.log(productIngredients);
            console.log(test_api_input.ingredients);
            if (productIngredients.length > 1) {
              test_api_input.ingredients = productIngredients;
            }
            console.log("^^^");
            console.log(productIngredients);
            console.log(test_api_input.ingredients);

            let selected = 0;

            fetch(final_api_url, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(test_api_input),
            })
              .then((response) => response.json())
              .then((data) => {
                //console.log("Response from API:", data);
                output_list = data.results;
                console.log('HELLO CELIA', output_list);
                console.log(output_list == undefined);
                if (output_list == undefined) {
                  output_list = temp_list;
                }
                load_images(output_list);
                load_info(0);
                const itemImages = document.querySelectorAll(".item-img");
                //console.log(itemImages);
                const productInfoLis =
                  document.querySelectorAll(".product-info-li");
                itemImages.forEach(function (itemImage) {
                  itemImage.addEventListener("click", function () {
                    console.log("---");
                    itemImages.forEach(function (img, index) {
                      img.classList.remove("active");
                    });
                    itemImage.classList.add("active");
                    selected = parseInt(
                      itemImage.getAttribute("data-product-id")
                    );
                    load_info(selected);
                    console.log(selected);
                  });
                });
              })
              .catch((error) => {
                console.error("API ERROR:", error);
              });
          }
        );
      });
    } else {
      const main_sec = document.getElementById("main-section");
      main_sec.innerHTML = "";
      let filler_text = document.createElement("h1");
      filler_text.textContent =
        "Please use this extension on a Sephora product item page.";
      filler_text.classList.add("filler-text");
      main_sec.append(filler_text);
    }
  });
});
