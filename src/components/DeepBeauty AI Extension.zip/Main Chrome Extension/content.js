// Product Title
let productTitle = "";
const titleElement = document.querySelector('[data-at="product_name"]');
if (titleElement) {
  productTitle = titleElement.textContent || titleElement.innerText;
}
//console.log("titleElement", titleElement);

// Product Category
let productCategory = "None available";
const productElement1 = document.querySelector('[aria-label="Breadcrumb"]');
//console.log("Wrapper Category", productElement1);
const productElement = productElement1.querySelector("ol li:last-child");
//console.log("Main Category", productElement);
if (productElement) {
  productCategory = productElement.textContent || productElement.innerText;
}

// Product Ingredients
let productIngredients = "";
const ingredientElement = document.querySelector("#ingredients div div");
console.log("Ingred Base", ingredientElement);
if (ingredientElement) {
  try {
    productIngredients =
      ingredientElement.textContent || ingredientElement.innerText;
  } catch (error) {
    console.log("An error occured", error.message);
  }
}

// Color Text
let productColorText = "";
try {
  const spanz = document.querySelectorAll("span");
  spanz.forEach((span) => {
    if (span.textContent.includes("Color: ")) {
      console.log("Span try", span);
      productColorText = span.textContent.split("Color:")[1].trim();
    }
  });
} catch (err) {
  console.log("Span Error", err.message);
}

// Look for the swatch section
// Look for the aria-selected=true
function getAverageColor(imageUrl, callback) {
  // Create an image element
  const img = new Image();
  img.crossOrigin = "Anonymous"; // Handle CORS issues if the image is hosted on another domain

  // When the image is loaded
  img.onload = function () {
    // Create a canvas element
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    // Set the canvas dimensions to match the image
    canvas.width = img.width;
    canvas.height = img.height;

    // Draw the image onto the canvas
    ctx.drawImage(img, 0, 0, img.width, img.height);

    // Get the image data from the canvas
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data; // This is an array of RGBA values

    let r = 0,
      g = 0,
      b = 0;
    const totalPixels = data.length / 4; // Each pixel has 4 values (RGBA)

    // Loop through all the pixels and accumulate the RGB values
    for (let i = 0; i < data.length; i += 4) {
      r += data[i]; // Red
      g += data[i + 1]; // Green
      b += data[i + 2]; // Blue
    }

    // Calculate the average values
    r = Math.floor(r / totalPixels);
    g = Math.floor(g / totalPixels);
    b = Math.floor(b / totalPixels);

    // Return the average color in RGB format (or as a hex value)
    const avgColor = `rgb(${r}, ${g}, ${b})`;
    callback(avgColor);
  };

  // Set the image source (this triggers the image loading)
  img.src = imageUrl;
}
let productColorRBG = "";
let img_url = "";
try {
  const aria_selector = '[aria-label="' + productColorText + '"]'
  const selectedButton = document.querySelector('button[data-at="selected_swatch"]');
  console.log("SELECTED BUTTON", selectedButton);
  const imgURLContainer = selectedButton.querySelector("img");
  console.log("IMAGE URL CONTAINER", imgURLContainer);
  if (imgURLContainer) {
    img_url = imgURLContainer.src;
  }
  if (img_url) {
    productColorRBG = getAverageColor(img_url, (avgColor) => {
      console.log("AVERAGE COLOR", avgColor);
      productColorRBG = avgColor;
    });
  }
} catch (err) {
  console.log("Average Color error", err.message);
}

// Color Image
// Example API would them be something like
let api_data = {
  product_name: productTitle,
  product_ingredients: productIngredients,
  product_category: productCategory,
  product_color_text: "TBD",
  product_color_rgb: "TBD",
};
let final_api_url = "https://aws.deepbeautyai.com/api/productMatch";

// Send the title back to the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getProductTitle") {
    sendResponse({ title: productTitle });
  } 
  if (message.action == "getColorText") {
    sendResponse({ colorText: productColorText });
  } 
  if (message.action == "getColorRGB") {
    sendResponse({ colorRGB: productColorRBG });
  } 
  if (message.action === "getProductCategory") {
    sendResponse({ category: productCategory });
  } 
  if (message.action === "getProductIngredients") {
    sendResponse({ ingredients: productIngredients });
  } 
  if (message.action == "getAPIdata") {
    sendResponse({ api_data: api_data})
  }
});






