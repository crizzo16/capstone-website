temp_2_url = "https://www.sephora.com/product/fenty-beauty-rihanna-gloss-bomb-stix-high-shine-gloss-stick-P511572?skuId=2787497&icid2=products%20grid:p511572:product";
temp_2_id = "2787497"
temp_2_list = [
  {
    product_name: "The Creme Shop Moisture Remedy Macaron Lip Balm, Strawberry Coconut, Strawberry Coconut",
    ingredients: "",
    image_url: "https://i.ebayimg.com/images/g/GyMAAOSwucBlhhYB/s-l1200.png",
    score: 0.926394,
    shopping_url: "https://www.google.com/search?tbm=shop&q=The+Creme+Shop+Moisture+Remedy+Macaron+Lip+Balm+Strawberry+Coconut+Strawberry+Coconut"
  },
  {
    product_name: "e.l.f. Cosmetics e.l.f. Hydrating Core Lip Shine, Cheery",
    ingredients: "",
    image_url: "https://i5.walmartimages.com/seo/e-l-f-Hydrating-Core-Lip-Shine-Cheery_cc643a92-178f-4b37-91f4-e3aeda481e6b.0d9e1b330a800c4b7dd2813cd9ca619b.jpeg?odnHeight=768&odnWidth=768&odnBg=FFFFFF",
    score: 0.92531836,
    shopping_url: "https://www.google.com/search?tbm=shop&q=elf+Cosmetics+elf+Hydrating+Core+Lip+Shine+Cheery"
  },
  {
    product_name: "CHANEL ROUGE COCO BAUME Hydrating Beautifying Tinted Lip Balm Buildable Colour, 928",
    ingredients: "",
    image_url: "https://media.ulta.com/i/ulta/2607783?w=1200&h=1200&fmt=auto",
    score: 0.92418325,
    shopping_url: "https://www.google.com/search?tbm=shop&q=CHANEL+ROUGE+COCO+BAUME+Hydrating+Beautifying+Tinted+Lip+Balm+Buildable+Colour+928"
  },
  {
    product_name: "Morphe Dripglas Drenched High Pigment Lip Gloss, Mauve Splash",
    ingredients: "",
    image_url: "https://media.ulta.com/i/ulta/2612034?w=1080&h=1080&fmt=auto",
    score: 0.9222872,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Morphe+Dripglas+Drenched+High+Pigment+Lip+Gloss+Mauve+Splash"
  },
  {
    product_name: "Bite Beauty Multistick, Cashew (2019 formulation)",
    ingredients: "",
    image_url: "",
    score: 0.9224199,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Bite+Beauty+Multistick+Cashew+2019+formulation"
  }
];

temp_3_id = "1359694";
temp_3_list = [
  {
    product_name: "Giorgio Armani Luminous Silk Foundation, 5.9 Medium-Neutral",
    ingredients: "",
    image_url: "https://www.giorgioarmanibeauty-usa.com/dw/image/v2/AANG_PRD/on/demandware.static/-/Sites-gab-master-catalog/default/dw86aefdb8/products/A041/Luminous%20Silk%20Foundation/GA_Luminous_Silk_Foundation_4.5_L425720_3360372075547_RVB.jpg",
    score: 0.93988407,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Giorgio+Armani+Luminous+Silk+Foundation+59+MediumNeutral"
  },
  {
    product_name: "Fenty Beauty Pro Filt'r Mattifying Primer (2019 formulation)",
    ingredients: "",
    image_url: "https://cdn.shopify.com/s/files/1/0341/3458/9485/products/36358_600x.jpg?v=1620846435",
    score: 0.9114466,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Fenty+Beauty+Pro+Filtr+Mattifying+Primer+2019+formulation"
  },
  {
    product_name: "E.l.f. Medium Coverage Flawless Satin Foundation, Chestnut 650 (2020 formulation)",
    ingredients: "",
    image_url: "https://target.scene7.com/is/image/Target/GUEST_9bb5f07a-dc4a-4c0b-88b6-bb4a08356f9f?wid=800&hei=800&qlt=80&fmt=pjpeg",
    score: 0.90845716,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Elf+Medium+Coverage+Flawless+Satin+Foundation+Chestnut+650+2020+formulation"
  },
  {
    product_name: "L.a. Girl Pro Matte hd.high Definition Long Wear Matte Foundation, Glm718 Sandy Beige (2019 formulation)",
    ingredients: "",
    image_url: "https://i5.walmartimages.com/seo/L-A-Girl-Pro-Matte-Foundation-Sandy-Beige-1-Fluid-Ounce_158f13f2-c04a-4ad6-a843-a345c8c30a1e.7ca1eab6aeefa3086180e99e563920b3.jpeg",
    score: 0.908192,
    shopping_url: "https://www.google.com/search?tbm=shop&q=La+Girl+Pro+Matte+hdhigh+Definition+Long+Wear+Matte+Foundation+Glm718+Sandy+Beige+2019+formulation"
  },
  {
    product_name: "Too Faced Peach Perfect Comfort Matte Foundation (2018 formulation)",
    ingredients: "",
    image_url: "https://www.temptalia.com/wp-content/uploads/2018/05/too-faced_chestnut_001_promo.jpg",
    score: 0.90305495,
    shopping_url: "https://www.google.com/search?tbm=shop&q=Too+Faced+Peach+Perfect+Comfort+Matte+Foundation+2018+formulation"
  }
]


// Automatically move the image section
const scrollContainer = document.getElementById("photos-section-id");
function handleMouseMove(event) {
  const containerWidth = scrollContainer.offsetWidth;
  const mouseX = event.clientX - scrollContainer.getBoundingClientRect().left;
  const scrollSpeed = 2; 
  const scrollPosition = mouseX / containerWidth;
  scrollContainer.scrollLeft = scrollPosition * (scrollContainer.scrollWidth - containerWidth);
}
scrollContainer.addEventListener('mousemove', handleMouseMove);


// Load all of the images from a list
function load_images(object_list) {
  // Grab the image section and delete any prior images
  const img_section = document.getElementById("photos-section-id");
  img_section.innerHTML = "";
  // For each image in the product list
  object_list.forEach((single, index) => {
    // Create the image
    const temp_wrapper = document.createElement("a");
    const temp_img = document.createElement("img");
    
    // If there is an image url present, show that image
    if (typeof single.image_url == "string" && single.image_url != "") {
      temp_img.src = single.image_url;
    } else { // Else show an image of a random color
      rand_img_number = Math.floor(Math.random() * (5 - 1 + 1) + 1);
      temp_img.src = "./images/Blank Picture " + rand_img_number + ".png";
    }

    // Add classes to each image
    temp_img.classList.add("item-img");
    temp_img.setAttribute("data-product-id", index);
    if (index === 0) {
      temp_img.classList.add("active");
    }

    // Do proper nesting and add if to the Extension for display
    temp_wrapper.append(temp_img);
    img_section.append(temp_wrapper);
  });
}


// Load information for a specific index on the Extension
function load_info(prod_index, stuff_list) {
  //Get the specific product
  const selected_product = stuff_list[prod_index];
  // Name
  document.getElementById("productTitle").textContent =
    selected_product.product_name;
  // Similarity Score
  temp_similar = Math.round(parseFloat(selected_product.ingredient_similarity_score) * 10000)/100;
  document.getElementById("sim-score").textContent =
    "Similarity Score: " + temp_similar.toString() + "%";
  // Google Shopping Link
  document.getElementById("product-link").href = selected_product.shopping_url;


  console.log(selected_product); // Debugging for seeing all info present
}


// Remove all 
function show_nothing(message_text) {
  // Remove everything from the main HTML div and let people know this page isn't supported
  const main_sec = document.getElementById("main-section");
  main_sec.innerHTML = "";
  let filler_text = document.createElement("h1");
  filler_text.textContent = message_text;
  filler_text.classList.add("filler-text");
  main_sec.append(filler_text);
}

document.addEventListener("DOMContentLoaded", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    
    // Get the URL of the page we're currently on
    page_url = tabs[0].url;

    // Only ping the API if we know we're on a Sephora product page
    if (page_url.includes("sephora.com") & page_url.includes("skuId")) {
      let final_api_url =
        "https://x9srsa41k6.execute-api.us-east-1.amazonaws.com/dev/api/predict-dupes";

      function assign_ingredients(response) {
        return response.ingredients;
      }
      chrome.tabs.sendMessage(
        tabs[0].id,
        { action: "getAPIdata" },
        (response) => {
          console.log("API DATA: ", response);
          const productIngredients = response.apidata.ingredients;
          best_input = response.apidata;
          best_input['top_n'] = 5; // Add this field to the API input

          // Always show the first product
          let selected = 0;

          // Fetch the response
          fetch(final_api_url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(best_input),
          })
            .then((response) => response.json())
            .then((data) => {
              // Get Data
              output_list = data.results;
              console.log('API RESPONSE', output_list); //Check for correct output
              //console.log(output_list == undefined); //Check for empty list
              if (output_list == undefined) {
                show_nothing("This product is not supported by DeepBeauty AI. Please try with a different makeup product.");
              }
              // Load all images of products
              load_images(output_list);
              // Load the first product as the selected product
              load_info(0, output_list);

              //Set it up to click on an image to select other product
              const itemImages = document.querySelectorAll(".item-img");
              itemImages.forEach(function (itemImage) {
                itemImage.addEventListener("click", function () {
                  // If selected, remove the Active from the current image
                  itemImages.forEach(function (img, index) {
                    img.classList.remove("active");
                  });
                  //Then 
                  itemImage.classList.add("active");
                  selected = parseInt(
                    itemImage.getAttribute("data-product-id")
                  );
                  load_info(selected, output_list);
                  //console.log(selected); // Check that selected item looks correct
                });
              });
            })
            .catch((error) => {
              console.error("API ERROR:", error);
            });
        }
      );
      
    } else {
      show_nothing("Please use this extension on a Sephora product item page.");
    }
  });
});
