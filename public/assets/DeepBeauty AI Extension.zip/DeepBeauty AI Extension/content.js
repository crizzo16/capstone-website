// Product Title
let productTitle = "";
const titleElement = document.querySelector('[data-at="product_name"]');
if (titleElement) {
  productTitle = titleElement.textContent || titleElement.innerText;
}

// Product Category
// Sephora Categories by Super Category
let cat_face = ["Moisturizers","Face Serums","Face Wash & Cleansers","Foundation","Makeup","Face Masks","Eyebrow","Setting Spray & Powder","Face Primer","Highlighter","Face Sunscreen","Blush","Concealer","Toners","Face Oils","Bronzer","Facial Peels","Anti-Aging","Exfoliators","Blemish & Acne Treatments","Sheet Masks","Scrub & Exfoliants","Makeup Removers","Contour","Makeup Palettes","Face Sets","Tinted Moisturizer","For Face","Night Creams","Moisturizer & Treatments","Cheek Palettes","BB & CC Cream","Color Correct","Face Wash","Skincare Sets","BB & CC Creams","Under-Eye Concealer","Cleansers"];
let cat_lips = ["Lipstick","Lip Balm & Treatment","Lip Gloss","Lip Balms & Treatments","Lip Liner","Liquid Lipstick","Lip Plumper","Lip Sets","Lip Stain","Lip"];
let cat_eyes = ["Eye Creams & Treatments","Mascara","Eye Palettes","Eyeliner","Eyeshadow","Eye Primer","Eye Sets","Eye Masks","Eye Cream","Eye"];
let cat_body = ["Body Lotions & Body Oils","Body Wash & Shower Gel","For Body","Deodorant & Antiperspirant","Hand Cream & Foot Cream","Decollete & Neck Creams","Shaving","Body Sunscreen","Bath & Body","Bath Soaks & Bubble Bath","Hand Sanitizer & Hand Soap","Body Products","Sunscreen","Body Moisturizers"];
let productCategory = "Other";
// Get the element from the page
const productElement1 = document.querySelector('[aria-label="Breadcrumb"]');
//console.log("Wrapper Category", productElement1);
const productElement = productElement1.querySelector("ol li:last-child");
//console.log("Main Category", productElement);
// Assign correct super_category
if (productElement) {
  temp_prod = productElement.textContent || productElement.innerText;
  if (cat_face.includes(temp_prod)) {
    productCategory = "Face";
  } else if (cat_lips.includes(temp_prod)) {
    productCategory = "Lips";
  } else if (cat_eyes.includes(temp_prod)) {
    productCategory = "Eyes";
  } else if (cat_body.includes(temp_prod)) {
    productCategory = "Body";
  } else {
    productCategory = "Other";
  }
}


//Product Brand
let productBrand = "None available";
const productBrand1 = document.querySelector('[data-at="brand_name"]');
if (productBrand1) {
  productBrand = productBrand1.textContent || productBrand1.innerText;
}

// Product Ingredients
let productIngredients = "";
const ingredientElement = document.querySelector("#ingredients div div");
//console.log("Ingred Base", ingredientElement);
if (ingredientElement) {
  try {
    productIngredients =
      ingredientElement.textContent || ingredientElement.innerText;
  } catch (error) {
    console.log("An error occured", error.message);
  }
}

/*
// Color Text
let productColorText = "";
try {
  // Inefficient, but does get teh job done
  const spanz = document.querySelectorAll("span");
  spanz.forEach((span) => {
    if (span.textContent.includes("Color: ")) {
      //console.log("Span try", span);
      productColorText = span.textContent.split("Color:")[1].trim();
    }
  });
} catch (err) {
  console.log("Span Error", err.message);
}

// Look for the swatch section
// Look for the aria-selected=true
function getAverageColor(imageUrl, callback) {
  // Create an image element
  const img = new Image();
  img.crossOrigin = "Anonymous"; // Handle CORS issues if the image is hosted on another domain

  // When the image is loaded
  img.onload = function () {
    // Create a canvas element
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    // Set the canvas dimensions to match the image
    canvas.width = img.width;
    canvas.height = img.height;

    // Draw the image onto the canvas
    ctx.drawImage(img, 0, 0, img.width, img.height);

    // Get the image data from the canvas
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data; // This is an array of RGBA values

    let r = 0,
      g = 0,
      b = 0;
    const totalPixels = data.length / 4; // Each pixel has 4 values (RGBA)

    // Loop through all the pixels and accumulate the RGB values
    for (let i = 0; i < data.length; i += 4) {
      r += data[i]; // Red
      g += data[i + 1]; // Green
      b += data[i + 2]; // Blue
    }

    // Calculate the average values
    r = Math.floor(r / totalPixels);
    g = Math.floor(g / totalPixels);
    b = Math.floor(b / totalPixels);

    // Return the average color in RGB format (or as a hex value)
    const avgColor = `rgb(${r}, ${g}, ${b})`;
    callback(avgColor);
  };

  // Set the image source (this triggers the image loading)
  img.src = imageUrl;
}
let productColorRBG = "";
let img_url = "";
try {
  const aria_selector = '[aria-label="' + productColorText + '"]'
  const selectedButton = document.querySelector('button[data-at="selected_swatch"]');
  //console.log("SELECTED BUTTON", selectedButton);
  const imgURLContainer = selectedButton.querySelector("img");
  //console.log("IMAGE URL CONTAINER", imgURLContainer);
  if (imgURLContainer) {
    img_url = imgURLContainer.src;
  }
  if (img_url) {
    productColorRBG = getAverageColor(img_url, (avgColor) => {
      console.log("AVERAGE COLOR", avgColor);
      productColorRBG = avgColor;
    });
  }
} catch (err) {
  console.log("Average Color error", err.message);
}*/

// Color Image
// Example API would them be something like
let api_data = {
  name: productTitle,
  ingredients: productIngredients,
  category: productCategory,
  brand: productBrand
};
//console.log("API DATA FOR DEEPBEAUTY", api_data);

// Send the information back to the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action == "getAPIdata") {
    sendResponse({ apidata: api_data})
  }
  if (message.action === "getProductTitle") {
    sendResponse({ title: productTitle });
  } 
  /*
  if (message.action == "getColorText") {
    sendResponse({ colorText: productColorText });
  } 
  if (message.action == "getColorRGB") {
    sendResponse({ colorRGB: productColorRBG });
  } */
  if (message.action === "getProductCategory") {
    sendResponse({ category: productCategory });
  } 
  if (message.action === "getProductIngredients") {
    sendResponse({ ingredients: productIngredients });
  } 
});






