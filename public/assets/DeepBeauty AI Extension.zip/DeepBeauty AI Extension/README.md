# Open Beauty Facts Extension

An extension that gets some information from the Open Beauty Facts API and displays it. 

## How to Set Up

* Open chrome://extensions
* In the upper right corner, toggle Developer Mode on.
* In the upper left area, select Load Unpacked. 
* From here, select the folder of the chrome extension you wish to load
* It will then display on the page like a regular extension

If there are errors, it will have an errors thing next to it. While testing the extension, I recommend pinning it so it's easier to find. 

## How to Use

To use this extension, open any specific item on the open beauty facts website. When you open the Chrome Extension, it will show the name of the item, the ingredients, and a picture of the item. 